import Vue from 'vue'
import App from './App.vue'

import VueRouter from 'vue-router';
import routes from './routes';

Vue.config.productionTip = false

var router = new VueRouter({
  routes:routes,
  mode:'history'
});

Vue.use(VueRouter);

new Vue({
  render: h => h(App),
  router :router
}).$mount('#app')
