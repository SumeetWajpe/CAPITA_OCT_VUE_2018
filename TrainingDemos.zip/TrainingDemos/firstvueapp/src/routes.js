

import ProductComponent from './components/product.component.vue'
import CourseComponent from './components/course.component.vue'

 var routes=[
    {path:'/',component:ProductComponent},
    {path:'/courses/:id',component:CourseComponent}
];

export default routes;