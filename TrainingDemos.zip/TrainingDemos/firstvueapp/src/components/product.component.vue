<template>
  <!-- <div>
    <slot name="title"></slot>
    <hr/>
    
  <div class="Highlight">
    <slot></slot>
  </div>  
  </div> -->
  <div class="jumbotron">
  <h1> Product Component ! </h1>

  </div>
</template>

<script>
export default {
  name:'Product'
}
</script>

<style scoped>
.Highlight{
 border: 2px solid red;
}
</style>
