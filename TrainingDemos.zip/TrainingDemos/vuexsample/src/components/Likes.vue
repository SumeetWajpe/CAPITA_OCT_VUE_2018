<template>
  <div>
  <h1> {{countOfLikes}} </h1>
  
  <button class="btn btn-primary" @click="addlikes">
    Likes 
    <span class="glyphicon glyphicon-thumbs-up"></span>
  </button>

  <button class="btn btn-warning" @click="dislikes">
    Dislikes 
    <span class="glyphicon glyphicon-thumbs-down"></span>
  </button>

   <button class="btn btn-info" @click="updatelikes">
    Update likes after 3 seconds !
    <span class="glyphicon glyphicon-thumbs-"></span>
  </button>
</div>

</template>

<script>

import store from '../store/store';
export default {
  computed:{
    countOfLikes(){
     return store.state.likes
    }
  },methods:{
    addlikes(){
      store.commit('incrementlikes');
    },dislikes(){
      store.commit('decrementlikes',10);
    },
    updatelikes(){
       store.commit('updateLikesAfterThree');
    }
  } 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
 
</style>
