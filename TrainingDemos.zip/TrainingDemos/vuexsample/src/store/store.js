import Vuex from 'vuex';
import Vue from 'vue';

Vue.use(Vuex);


export default new Vuex.Store({
    state:{
        likes:0
    },
    mutations:{
        incrementlikes(state){
                state.likes++;
        },
        decrementlikes(state,noOfLikes){
            state.likes--;
        }
    },
    actions:{
            updateLikesAfterThree({commit}){
                setTimeout( ()=> commit('incrementlikes'),3000)
            }
    }
})
