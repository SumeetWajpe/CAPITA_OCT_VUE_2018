import { shallowMount } from '@vue/test-utils'
import Message from '@/components/Message.vue'

describe('Message.vue', () => {
  it('renders props.msg when passed', () => {
    const mymsg = 'new message'
    const wrapper = shallowMount(Message, {
      propsData: { msg:mymsg }
    })
    expect(wrapper.text()).toBe(mymsg)
  })

  it('renders default message if not passed a prop', () => {
    const defaultMessage = 'some default message'
    const wrapper = shallowMount(Message)
    expect(wrapper.text()).toBe(defaultMessage)
  })
})
