<template>
  <div>
    <!-- <h1> {{coursename.name}} </h1>
    <b> Price : {{coursename.price}} </b>
  -->

    <h1> {{coursename}} </h1>

<p class="Highlight"> Child Component Para !</p>

<input type="button" 
value="Change Name !" 
@click="switchName" />

  </div>
</template>

<script>
export default {
  name: 'Course',
  props:['coursename'],
  methods:{
    switchName(){      
      this.coursename = ".NET";
      this.$emit("thenamewaschanged",this.coursename);
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.Highlight{
  background-color: red;
}
</style>
