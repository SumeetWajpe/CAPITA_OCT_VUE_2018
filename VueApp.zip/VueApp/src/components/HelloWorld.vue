<template>
  <div>
    <h1> {{msg}} </h1>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props:{
    msg:{
      default:'XYZ',
      type:[String,Number]

    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>

</style>
