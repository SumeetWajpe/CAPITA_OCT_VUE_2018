<template>
  <div id="app">

    <!-- <button class="btn btn-success"> <router-link to="/"> Home  </router-link> </button>
     <button class="btn btn-success">  <router-link to="/courses"> Courses  </router-link> </button> -->


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Routing</a>
    </div>
    <ul class="nav navbar-nav">
      <li ><router-link to="/"> Home  </router-link></li>
      <li><router-link to="/courses/10"> Courses  </router-link> </li>
     
    </ul>
  </div>
</nav>

      <router-view></router-view>
  </div>
</template>

<script>

import ProductComponent from './components/product.component.vue'
import CourseComponent from './components/course.component.vue'

export default {
  name: 'app',
  components: {
            ProductComponent,
            CourseComponent
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
